try {
var pageTracker = _gat._getTracker("UA-9910068-1");
pageTracker._trackPageview();
} catch(err) {}

