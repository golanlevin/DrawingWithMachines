Coding Guidelines and Standards
===============================

Please refer to `PEP8 <http://www.python.org/dev/peps/pep-0008/>`_.

