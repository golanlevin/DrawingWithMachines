Questions? Want to contribute?
================================

If you have questions, found a bug or want to contribute, please join the
`Chiplotle mailing list <http://music.columbia.edu/mailman/listinfo/chiplotle-discuss>`__. 

