# -*- coding: utf-8 -*-
from __future__ import unicode_literals


__title__ = "chiplotle"
__description__ = "Chiplotle is an HPGL Python API."
__version__ = "0.4.2"
__author__ = "Víctor Adán and Douglas Repetto"
__author_email__ = "chiplotle@music.columbia.edu"
__license__ = "GPL"
__copyright__ = "Copyright 2018 Chiplotle"
__url__ = "http://music.columbia.edu/cmc/chiplotle"
