from .interface import MarginsInterface, MarginsHard, MarginsSoft
