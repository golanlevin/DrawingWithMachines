## TODO: make this autoimport work
# from chiplotle.core.imports.package_import import _package_import
# _package_import(__path__[0], globals( ))

# from .get_centroid import get_centroid
# from .get_line_intersection import get_line_intersection
# from .get_line_intersection import get_line_intersection
# from .get_shape_intersections import get_shape_intersections
# from .scale import scale
# from .split_coordinatearray_proportionally import split_coordinatearray_proportionally
# from .split_vector_equidistantly import split_vector_equidistantly
