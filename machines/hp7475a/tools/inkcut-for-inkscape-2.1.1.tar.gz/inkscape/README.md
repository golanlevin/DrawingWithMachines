# Inkcut for Inkscape

To install the inkscape extensions for inkcut

Copy the files here to `~/.config/inkscape/extensions`

Inkcut must also be installed on your system for this extension to work
see [https://github.com/codelv/inkcut/](https://github.com/codelv/inkcut/)
