# Bail out if python version is less than currently required minimum
import sys
MIN_VERSION = (3, 6) # e.g., (3, 6) for Python version 3.6
if sys.version_info < MIN_VERSION:
    v_string = "version " + str(MIN_VERSION[0]) + "." + str(MIN_VERSION[1])
    sys.exit("AxiDraw software requires Python " + v_string + " or greater.")
